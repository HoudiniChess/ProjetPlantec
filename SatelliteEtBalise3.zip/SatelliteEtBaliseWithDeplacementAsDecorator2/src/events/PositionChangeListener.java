package events;

public interface PositionChangeListener {
	public void whenPositionChanged(PositionChanged arg);
}
