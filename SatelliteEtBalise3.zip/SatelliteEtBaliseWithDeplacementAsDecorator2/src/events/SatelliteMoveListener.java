package events;

public interface SatelliteMoveListener
{
  public void whenSatelliteMoved(SatelliteMoved arg);
}
