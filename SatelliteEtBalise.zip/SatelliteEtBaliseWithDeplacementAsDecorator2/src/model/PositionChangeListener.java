package model;

public interface PositionChangeListener {
	public void whenPositionChanged(PositionChanged arg);
}
