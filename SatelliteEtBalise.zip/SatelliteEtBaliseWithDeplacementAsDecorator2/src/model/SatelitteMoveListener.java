package model;

public interface SatelitteMoveListener {
	public void whenSatelitteMoved(SatelitteMoved arg);
}
